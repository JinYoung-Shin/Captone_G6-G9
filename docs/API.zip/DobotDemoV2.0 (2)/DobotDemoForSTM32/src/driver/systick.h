#ifndef SYSTICK_H
#define SYSTICK_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern void SystickInit(void);

#ifdef __cplusplus
}
#endif


#endif
